
import Layout from '../components/Layout'
export default function Contact(){
  return (
    <Layout active="contact">
      <section className="max-w-6xl mx-auto px-6 py-16 grid md:grid-cols-2 gap-8">
        <div>
          <div className="uppercase text-xs text-muted">Contact</div>
          <h2 className="text-3xl font-serif">For specifications, sampling or project discussions, reach us.</h2>
          <p className="text-sm text-muted mt-3">We participate in trade fairs including IHGF Delhi Fair & Maison Objet Paris. To schedule a meeting, contact us.</p>
          <div className="grid grid-cols-3 gap-3 mt-6">
            <div className="card"><div className="h-24 bg-stonegray"></div></div>
            <div className="card"><div className="h-24 bg-stonegray"></div></div>
            <div className="card"><div className="h-24 bg-stonegray"></div></div>
          </div>
        </div>
        <div>
          <form className="grid grid-cols-1 gap-3" onSubmit={(e)=>{e.preventDefault(); alert('Thanks — we reply within two business days.')}}>
            <input placeholder="Name*" required className="p-3 rounded-xl border border-stonegray"/>
            <input placeholder="Company / Role*" required className="p-3 rounded-xl border border-stonegray"/>
            <input placeholder="Region" className="p-3 rounded-xl border border-stonegray"/>
            <select className="p-3 rounded-xl border border-stonegray">
              <option>Project Intent*</option><option>Sampling</option><option>Order</option>
            </select>
            <input placeholder="Ship-to country" className="p-3 rounded-xl border border-stonegray"/>
            <input placeholder="Email*" type="email" required className="p-3 rounded-xl border border-stonegray"/>
            <textarea placeholder="Message / Notes" className="p-3 rounded-xl border border-stonegray"></textarea>
            <div className="flex items-center space-x-3">
              <input type="file"/>
              <div className="text-sm text-muted">Optional: drawings/specs</div>
            </div>
            <button className="btn btn-primary mt-4">Submit</button>
            <p className="text-sm text-muted mt-2">*We reply within two business days.</p>
          </form>
        </div>
      </section>
    </Layout>
  )
}
