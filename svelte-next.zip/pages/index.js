
import Layout from '../components/Layout'
import Hero from '../components/Hero'
import MaterialCard from '../components/MaterialCard'
export default function Home() {
  const materials = [
    {title:'Onyx', caption:'Translucent, expressive; lighting & sculptural objects', img:'/assets/onyx.jpg'},
    {title:'Travertine', caption:'Textural depth for tables & benches', img:'/assets/travertine.jpg'},
    {title:'Marble', caption:'Durable, timeless; furniture & surfaces', img:'/assets/marble.jpg'},
    {title:'Alabaster', caption:'Soft, luminous; refined lighting', img:'/assets/alabaster.jpg'},
  ]
  return (
    <Layout active="home">
      <Hero />
      <section className="max-w-6xl mx-auto px-6 py-16">
        <div className="mb-6">
          <div className="uppercase text-xs text-muted">Materials</div>
          <h2 className="text-3xl font-serif">Selected Stones</h2>
          <p className="text-sm text-muted mt-2">A quiet preview — explore four core materials, with more within.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {materials.map(m => <MaterialCard key={m.title} {...m} />)}
        </div>
      </section>
    </Layout>
  )
}
