
import Layout from '../components/Layout'
import JournalCard from '../components/JournalCard'
export default function Journal(){
  const posts = [
    {title:'Caring for Onyx: What to Know Before You Specify', excerpt:'Notes on care, variation and finishes for translucent stones.'},
    {title:'Why Travertine Works Beyond Architecture', excerpt:'Texture, depth and how to position it in objects.'},
    {title:'Offcuts as Objects: Reducing Waste in Stone', excerpt:'Turning remnants into thoughtful collectibles.'},
    {title:'Tolerance Controls in Hand Finishing', excerpt:'Aligning design intent with measured outcomes.'},
    {title:'Packing Standards for Global Transit', excerpt:'Moisture barriers, crate photos and damage prevention.'},
    {title:'Sampling to Production: A Process', excerpt:'Prototyping that shortens feedback loops.'},
  ]
  return (
    <Layout active="journal">
      <section className="max-w-6xl mx-auto px-6 py-16">
        <div className="mb-6">
          <div className="uppercase text-xs text-muted">Journal</div>
          <h2 className="text-3xl font-serif">Notes on stone, design and process.</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {posts.map(p => <JournalCard key={p.title} {...p} />)}
        </div>
      </section>
    </Layout>
  )
}
