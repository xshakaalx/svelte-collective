
import Layout from '../components/Layout'
import MaterialCard from '../components/MaterialCard'
export default function Materials(){
  const materials = [
    {title:'Onyx', caption:'Translucent; lighting & sculptural pieces', img:'/assets/onyx.jpg'},
    {title:'Travertine', caption:'Textural; tables, benches', img:'/assets/travertine.jpg'},
    {title:'Marble', caption:'Durable; furniture & surfaces', img:'/assets/marble.jpg'},
    {title:'Alabaster', caption:'Luminous; refined lighting', img:'/assets/alabaster.jpg'},
  ]
  return (
    <Layout active="materials">
      <section className="max-w-6xl mx-auto px-6 py-16">
        <div className="mb-6">
          <div className="uppercase text-xs text-muted">Materials</div>
          <h2 className="text-3xl font-serif">Stone, refined and export-ready.</h2>
          <p className="text-sm text-muted mt-2">Stone can be translucent, textured, luminous. Our role is to make those possibilities consistent and usable.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {materials.map(m=> <MaterialCard key={m.title} {...m} />)}
        </div>

        <div className="grid md:grid-cols-2 gap-6 mt-8">
          <div className="card p-6"><h3 className="font-serif text-xl">Design Support</h3><p className="text-sm text-muted mt-2">CAD drawings, sampling and prototypes before production.</p></div>
          <div className="card p-6"><h3 className="font-serif text-xl">Making</h3><p className="text-sm text-muted mt-2">Finishing options and tolerance controls.</p></div>
        </div>

        <div className="lead-times mt-8 p-4 rounded-xl text-white" style={{background:'#B6A179'}}>
          <strong>Lead Times:</strong> Small objects 6–8 weeks — Larger furniture 10–12 weeks
        </div>

        <div className="grid md:grid-cols-2 gap-6 mt-6">
          <div><h3 className="font-serif text-xl">Certifications</h3><p className="text-sm text-muted mt-2">Sedex, CE/UL, Make in India</p></div>
          <div><h3 className="font-serif text-xl">Fair Work</h3><p className="text-sm text-muted mt-2">Workshops organised with dignity; fair value for artisans.</p></div>
        </div>
      </section>
    </Layout>
  )
}
