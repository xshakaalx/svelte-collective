
import Layout from '../components/Layout'
export default function Philosophy(){
  return (
    <Layout active="philosophy">
      <section className="max-w-6xl mx-auto px-6 py-16 grid md:grid-cols-2 gap-8">
        <div>
          <div className="uppercase text-xs text-muted">Philosophy</div>
          <h2 className="text-3xl font-serif">Doing the basics well.</h2>
          <p className="text-sm text-muted mt-4">In a trade often driven by volume and speed, we choose clarity and discipline. Every order is backed by drawings, documented QC, and crate photos before dispatch. This is how we ensure consistent and reliable standards.</p>
        </div>
        <div className="card">
          <div className="h-56 bg-stonegray"></div>
        </div>
      </section>

      <section className="bg-[rgba(220,215,210,0.35)] py-12">
        <div className="max-w-6xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="p-6"><h3 className="text-xl font-serif">Respect</h3><p className="text-sm text-muted mt-2">Lead times stated upfront; responses within two business days.</p></div>
          <div className="p-6"><h3 className="text-xl font-serif">Quality</h3><p className="text-sm text-muted mt-2">Measured standards; documented checks on every order.</p></div>
          <div className="p-6"><h3 className="text-xl font-serif">Craftsmanship</h3><p className="text-sm text-muted mt-2">Hand finishing supported by CAD drawings and tolerance controls.</p></div>
          <div className="p-6"><h3 className="text-xl font-serif">Authenticity</h3><p className="text-sm text-muted mt-2">Capability over claims; materials and processes presented clearly.</p></div>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-6 py-12">
        <div className="card overflow-hidden">
          <div className="h-44" style={{background:'linear-gradient(0deg, rgba(0,0,0,0.12), rgba(0,0,0,0.12)), url(/assets/made_in_india.jpg) center/cover'}}></div>
          <div className="p-6">
            <h3 className="text-2xl font-serif">Made in India</h3>
            <p className="text-sm text-muted mt-2">Combining artisanal skill with design-led systems to bring refinement to stone manufacturing.</p>
            <div className="mt-4"><a className="btn btn-primary" href="/contact">Work with us</a></div>
          </div>
        </div>
      </section>
    </Layout>
  )
}
