const nextConfig = { reactStrictMode: true, images: { disableStaticImages: true } }
module.exports = nextConfig;
